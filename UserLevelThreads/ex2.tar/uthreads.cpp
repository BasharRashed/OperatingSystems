#include "uthreads.h"
#include "Thread.h"
#include <iostream>
#include <queue>
#include <signal.h>
#include <setjmp.h>
#include <sys/time.h>
#include <cstdlib>

#define FAIL -1
#define SUCCESS 0
#define QUANTUM_USECS_ERR "thread library error: quantum_usecs must be positive"
#define SIGACTION_ERR "system error: sigaction failed"
#define TIMER_ERR "system error: setitimer failed"
#define INVALID_ENTRY_PTR "thread library error: invalid function pointer"
#define UNAVAILABLE_THREAD_ERR "thread library error: no available thread ID"
#define TID_VALIDATION_ERR "thread library error: invalid thread ID"
#define MAIN_THREAD_BLOCK_ERR "thread library error: cannot block main thread"
#define NUM_OF_QUANTUMS_ERR "thread library error: invalid number of quantums to sleep"
#define MAIN_THREAD_SLEEP_ERR "thread library error: main thread cannot sleep"



static Thread* threads[MAX_THREAD_NUM];
static int current_tid =0;
static int total_quantums =0;
static int quantum_usecs_global =0;
static std::queue<int> ready_queue;



void scheduler_handler(int sig); // Forward declaration

int uthread_init(int quantum_usecs){
    if (quantum_usecs <= 0){
        std::cerr << QUANTUM_USECS_ERR << std::endl;
        return FAIL;
    }

    quantum_usecs_global = quantum_usecs;
    total_quantums = 1;
    current_tid = 0;

    threads[0] = new Thread();
    threads[0]->active = 1;
    threads[0]->quantum_count = 1;

    while (!ready_queue.empty()){
        ready_queue.pop();
    }

    struct sigaction sa = {};
    sa.sa_handler = &scheduler_handler;
    if (sigaction(SIGVTALRM, &sa, nullptr) < 0){
        std::cerr << SIGACTION_ERR << std::endl;
        exit(1);
    }

    struct itimerval timer;
    timer.it_value.tv_sec = quantum_usecs_global / 1000000;
    timer.it_value.tv_usec = quantum_usecs_global % 1000000;
    timer.it_interval.tv_sec = timer.it_value.tv_sec;
    timer.it_interval.tv_usec = timer.it_value.tv_usec;

    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr) < 0){
        std::cerr << TIMER_ERR << std::endl;
        exit(1);
    }

    return SUCCESS;
}

void scheduler_handler(int sig)
{
    //if sig is nonzero, this means timer expired ( quantum passed)
    bool timer_fired = (sig != 0);
    int ret_val = sigsetjmp(threads[current_tid]->get_env()[0], 1);

    if (ret_val == 1)
    {
        return;
    }
    if (threads[current_tid] != nullptr &&
        threads[current_tid]->active == 1 &&
        threads[current_tid]->getState() == RUNNING)
    {
        threads[current_tid]->setState(READY);
        ready_queue.push(current_tid);
    }

    //only decrement sleeping threads when timer really expired
    if (timer_fired)
    {
        for (int i = 0; i < MAX_THREAD_NUM; ++i)
        {
            if (threads[i] != nullptr && threads[i]->active &&
                threads[i]->getState() == BLOCKED && threads[i]->sleep_quantums > 0)
            {
                threads[i]->sleep_quantums--;

                if (threads[i]->sleep_quantums == 0)
                {
                    threads[i]->setState(READY);
                    ready_queue.push(i);
                }
            }
        }
        //increment quantums passed
        total_quantums++;
        threads[current_tid]->quantum_count++;
    }
    //next ready thread
    if (!ready_queue.empty())
    {
        int next_tid = ready_queue.front();
        ready_queue.pop();

        current_tid = next_tid;
        threads[current_tid]->setState(RUNNING);
        if(threads[current_tid]->quantum_count == 0){
            threads[current_tid]->quantum_count = 1;
            total_quantums++;
        }
    }
    else
    {
        return;
    }

    //restart timer for next quantum
    struct itimerval timer;
    timer.it_value.tv_sec = quantum_usecs_global / 1000000;
    timer.it_value.tv_usec = quantum_usecs_global % 1000000;
    timer.it_interval.tv_sec = timer.it_value.tv_sec;
    timer.it_interval.tv_usec = timer.it_value.tv_usec;

    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr) < 0)
    {
        std::cerr << TIMER_ERR << std::endl;
        exit(1);
    }
    siglongjmp(threads[current_tid]->get_env()[0], 1);
}


int uthread_spawn(thread_entry_point entry_point){

    if (entry_point == nullptr){
        std::cerr << INVALID_ENTRY_PTR << std::endl;
        return FAIL;
    }

    int tid = -1;
    for (int i = 0; i < MAX_THREAD_NUM; ++i){
        if (threads[i] == nullptr || !threads[i]->active){
            tid = i;
            break;
        }
    }

    if (tid == -1){
        std::cerr << UNAVAILABLE_THREAD_ERR << std::endl;
        return FAIL;
    }
    threads[tid] = new Thread(entry_point, tid);
    threads[tid]->active = 1;
    threads[tid]->setState(READY);
    threads[tid]->set_quantum_count(0);


    sigjmp_buf* env = threads[tid]->get_env();
    if(sigsetjmp(*env,1)==0) {
        address_t sp = (address_t)(threads[tid]->getStack()) + STACK_SIZE - sizeof(address_t);
        address_t pc = (address_t)(threads[tid]->get_entry_point());
        (*env)->__jmpbuf[JB_SP] = translate_address(sp);
        (*env)->__jmpbuf[JB_PC] = translate_address(pc);
        sigemptyset(&(*env)->__saved_mask);
    }
    ready_queue.push(tid);
    return tid;
}

int uthread_terminate(int tid){
    if (tid < 0 || tid > MAX_THREAD_NUM || threads[tid] == nullptr || !threads[tid]->active){
        std::cerr << TID_VALIDATION_ERR << std::endl;
        return FAIL;
    }

    // check if main thread
    if (tid == 0)
    {
        // clean all other threads
        for (int i = 1; i < MAX_THREAD_NUM; ++i){
            if (threads[i] != nullptr){
                delete threads[i];
                threads[i] = nullptr;
            }
        }
        delete threads[tid];
        while (!ready_queue.empty()){
            ready_queue.pop();
        }
        exit(0);
    }
    // remove thread from ready_queue
    ThreadState state = threads[tid]->getState();
    if (state == READY){
        std::queue<int> new_queue;
        while (!ready_queue.empty()){
            int curr_tid = ready_queue.front();
            ready_queue.pop();
            if (curr_tid != tid){
                new_queue.push(curr_tid);
            }
        }
        ready_queue = new_queue;
    }

    if (tid == current_tid){
        threads[tid]->active = 0;
        scheduler_handler(0);
    }
    else{
        delete threads[tid];
        threads[tid] = nullptr;
    }
    return SUCCESS;
}



int uthread_block(int tid){
    // check tid validation and if thread is active
    if (tid < 0 || tid > MAX_THREAD_NUM || threads[tid] == nullptr || !threads[tid]->active){
        std::cerr << TID_VALIDATION_ERR << std::endl;
        return FAIL;
    }

    //cannot block the main thread
    if (tid == 0){
        std::cerr << MAIN_THREAD_BLOCK_ERR << std::endl;
        return FAIL;
    }

    //if blocking a blocked thread, do nothing
    if (threads[tid]->getState() == BLOCKED){
        return SUCCESS;
    }

    //remove the thread from ready_queue to block it
    if (threads[tid]->getState() == READY){
        std::queue<int> new_queue;
        while (!ready_queue.empty()){
            int curr_tid = ready_queue.front();
            ready_queue.pop();
            if (curr_tid != tid){
                new_queue.push(curr_tid);
            }
        }
        ready_queue = new_queue;
    }
    threads[tid]->setState(BLOCKED);

    //if blocking the current running thread, then switch
    if (tid == current_tid){
        scheduler_handler(0);
    }
    return SUCCESS;
}

int uthread_resume(int tid){
    // check tid validation and if thread is active
    if (tid < 0 || tid > MAX_THREAD_NUM || threads[tid] == nullptr || !threads[tid]->active){
        std::cerr << TID_VALIDATION_ERR << std::endl;
        return FAIL;
    }

    if (tid == 0 || tid == current_tid || threads[tid]->getState()==READY){
        return SUCCESS;
    }

    threads[tid]->setState(READY);
    ready_queue.push(tid);
    return SUCCESS;
}

int uthread_sleep(int num_quantums){
    if (num_quantums <= 0)
    {
        std::cerr << NUM_OF_QUANTUMS_ERR << std::endl;
        return FAIL;
    }

    if (current_tid == 0)
    {
        std::cerr << MAIN_THREAD_SLEEP_ERR << std::endl;
        return FAIL;
    }

    threads[current_tid]->sleep_quantums = num_quantums;

    threads[current_tid]->setState(BLOCKED);

    scheduler_handler(0);

    return SUCCESS;
}

int uthread_get_tid()
{
    return current_tid;
}

int uthread_get_total_quantums()
{
    return total_quantums;
}

int uthread_get_quantums(int tid){
    if (tid < 0 || tid > MAX_THREAD_NUM || threads[tid] == nullptr || !threads[tid]->active)
    {
        std::cerr << TID_VALIDATION_ERR << std::endl;
        return FAIL;
    }
    return threads[tid]->quantum_count;
}
